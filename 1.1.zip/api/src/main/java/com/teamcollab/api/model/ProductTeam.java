package com.teamcollab.api.model;

public class ProductTeam {
    private String teamName;

    public ProductTeam(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamName() {
        return teamName;
    }
}
